﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace User_Story_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            //Provide Folder physical address to save the file
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\shivaban\source\repos\User_Story_1\input_user_story_1.txt");

            string output = string.Empty;

            while ((line = file.ReadLine()) != null)
            {
                char[] line1 = line.ToCharArray();
                char[] line2 = file.ReadLine().ToCharArray();
                char[] line3 = file.ReadLine().ToCharArray();

                char[,] arr = new char[3, 3];
                for (int j = 0; j < 9; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {

                        arr[0, k] = line1[k + (3 * j)];
                        arr[1, k] = line2[k + (3 * j)];
                        arr[2, k] = line3[k + (3 * j)];
                    }


                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == '|') && (arr[1, 1] == ' ') &&
                        (arr[1, 2] == '|') && (arr[2, 0] == '|') && (arr[2, 1] == '_') && (arr[2, 2] == '|'))
                    {
                        output += "0";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == ' ') && (arr[0, 2] == ' ') && (arr[1, 0] == ' ') && (arr[1, 1] == ' ') &&
                        (arr[1, 2] == '|') && (arr[2, 0] == ' ') && (arr[2, 1] == ' ') && (arr[2, 2] == '|'))
                    {
                        output += "1";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == ' ') && (arr[1, 1] == '_') &&
                            (arr[1, 2] == '|') && (arr[2, 0] == '|') && (arr[2, 1] == '_') && (arr[2, 2] == ' '))
                    {
                        output += "2";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == ' ') && (arr[1, 1] == '_') &&
                        (arr[1, 2] == '|') && (arr[2, 0] == ' ') && (arr[2, 1] == '_') && (arr[2, 2] == '|'))
                    {
                        output += "3";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == ' ') && (arr[0, 2] == ' ') && (arr[1, 0] == '|') && (arr[1, 1] == '_') &&
                        (arr[1, 2] == '|') && (arr[2, 0] == ' ') && (arr[2, 1] == ' ') && (arr[2, 2] == '|'))
                    {
                        output += "4";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == '|') && (arr[1, 1] == '_') &&
                        (arr[1, 2] == ' ') && (arr[2, 0] == ' ') && (arr[2, 1] == '_') && (arr[2, 2] == '|'))
                    {
                        output += "5";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == '|') && (arr[1, 1] == '_') &&
                        (arr[1, 2] == ' ') && (arr[2, 0] == '|') && (arr[2, 1] == '_') && (arr[2, 2] == '|'))
                    {
                        output += "6";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == ' ') && (arr[1, 1] == ' ') &&
                        (arr[1, 2] == '|') && (arr[2, 0] == ' ') && (arr[2, 1] == ' ') && (arr[2, 2] == '|'))
                    {
                        output += "7";
                    }
                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == '|') && (arr[1, 1] == '_') &&
                        (arr[1, 2] == '|') && (arr[2, 0] == '|') && (arr[2, 1] == '_') && (arr[2, 2] == '|'))
                    {
                        output += "8";
                    }

                    if ((arr[0, 0] == ' ') && (arr[0, 1] == '_') && (arr[0, 2] == ' ') && (arr[1, 0] == '|') && (arr[1, 1] == '_') &&
                       (arr[1, 2] == '|') && (arr[2, 0] == ' ') && (arr[2, 1] == '_') && (arr[2, 2] == '|'))
                    {
                        output += "9";
                    }
                }

                output += Environment.NewLine;
            }
            //Provide Folder physical address to save the file
            System.IO.File.WriteAllText(@"C:\Users\shivaban\source\repos\User_Story_1\output_user_story_1.txt", output);
        }
    }
}
