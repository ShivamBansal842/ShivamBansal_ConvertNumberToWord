﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using convertNumberToWord.Models;
using convertNumberToWord.Controllers;
using convertNumberToWord.Helper;

namespace convertNumberToWordTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void NumberToWordTestCase()
        {
            NumberToWordController numberToWordController = new NumberToWordController();
            string name = "Shivam bansal";
            string number = "12";

            ConvertNumberToWord actual = numberToWordController.Get(name, number);
            ConvertNumberToWord expected = new ConvertNumberToWord(name, number);
            expected.NumberInWord = "TWELVE DOLLARS ";

            Assert.AreEqual(actual.NumberInWord, expected.NumberInWord);
        }
    }
}

