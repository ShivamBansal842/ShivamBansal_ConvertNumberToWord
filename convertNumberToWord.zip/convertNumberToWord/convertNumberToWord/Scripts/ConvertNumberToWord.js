﻿function ConvertNumberToWord(e) {
    if (confirm('Are you sure?')) {
        var inputData = { Name: $("#Name").val(), Number: $("#Number").val() };
        $.ajax({
            url: 'api/NumberToWord',
            data: inputData,
            method: 'GET',
            type: 'GET',
            contentType: "application/json",
            //data: JSON.stringify({ input: inputData }),
            dataType: "json",
            success: function (data) {
                $("#lblNumberInWord").text(data.NumberInWord);
                $("#lblName").text(data.Name);
            }
        })
            .done(function () {  
        })
        .fail(function () {
            alert('Failed to delete.');
        });
    }    
}


$(document).ready(function () { 

    
    $("#Number").keydown(function (event) {
        if (event.shiftKey) {
            event.preventDefault();
        }
        if (event.keyCode === 46 || event.keyCode === 8 || event.keyCode === 110)
        {
            //Do nothing
        }
        else {
            if (event.keyCode < 95) {
                if (event.keyCode < 48 || event.keyCode > 57) {
                    event.preventDefault();
                }
            }
            else {
                if (event.keyCode < 96 || event.keyCode > 105) {
                    event.preventDefault();
                }
            }
        }
       
    });
    $("#btnSave").click(function () {
        debugger;
        var textVal = $("#Number").val();
        var regex = /^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$/;
        if (regex.test(textVal)) {
            ConvertNumberToWord();
        }
        else {
            
            alert('greater than zero with 2 decimal places'); 
        }
    });
});
$(document).ready(function () {

    $('#Name').keypress(function (e) {
        //var regex = new RegExp("^[a-zA-Z]$");
        var regex = new RegExp("^[a-zA-Z]$");
        var max = 50;
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            if (this.value.length === max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
            return true;
        }
        else {
            e.preventDefault();
            alert('Please Enter Alphabat');
            return false;
        }
    });
});
