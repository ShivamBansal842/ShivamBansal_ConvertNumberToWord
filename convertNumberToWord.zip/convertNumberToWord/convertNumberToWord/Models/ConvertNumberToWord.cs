﻿using System.ComponentModel.DataAnnotations;

namespace convertNumberToWord.Models
{
    public class ConvertNumberToWord
    {
        public ConvertNumberToWord(string _name, string _number)
        {
            Name = _name;
            Number = _number;
        }
        [Required]
        [StringLength(50, MinimumLength = 4)]
        public string Name { get; set; }
        [Required]
        [DataType(DataType.Currency)]
        public string Number { get; set; }
        [Display(Name = "Number In Word")]
        public string NumberInWord { get; set; }
    }
}