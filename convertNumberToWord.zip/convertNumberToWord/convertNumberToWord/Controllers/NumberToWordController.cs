﻿using convertNumberToWord.Helper;
using convertNumberToWord.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace convertNumberToWord.Controllers
{
    public class NumberToWordController : ApiController
    {
        public ConvertNumberToWord Get(string name, string number)       
        {
            ConvertNumberToWord input = new ConvertNumberToWord(name, number);
            string isNegative = "";
            try
            {
                
                if (input.Number.Contains("-"))
                {
                    isNegative = "Minus ";
                    input.Number = input.Number.Substring(1, number.Length - 1);
                }
                if (input.Number == "0")
                {
                    input.NumberInWord = "Zero";
                }
                else
                {
                    input.NumberInWord = isNegative + (NumberToWordConverter.ConvertToWords(number)).ToUpper();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return input;
            }
            return input;
        }
    }
}
