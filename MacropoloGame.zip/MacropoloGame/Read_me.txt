
Assumptions:
1. Connsider input as an array of integer.
2. Display output as an array of string.

Steps to Follow to run program:

1. Press f5 to run the solution.
2. After Executing the program enter the size of array--> for example 30.
3. Then it will ask you to enter element 
4. Enter first element and then press enter
5. It will ask you to enter another element
6. repeat step 4 and 5 till you have enterted all the elements
7. after entering last element press enter, it will show you the expected output.

Steps to Follow to run test case:
1.In the Menu bar select Test-->Debug-->All Tests
