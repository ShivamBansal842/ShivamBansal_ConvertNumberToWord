﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MacropoloGame
{
    public class Program
    {
        int i, n;
        public string[] display(int[] arr, int n, ref string[] arr1)
        {
            arr1 = arr.Select(x => x.ToString()).ToArray();
            for (i = 0; i < n; i++)
            {
                if (arr[i] % 4 == 0)
                {
                    if (arr[i] % 7 == 0)
                    {
                        arr1[i] = "marcopolo";


                    }
                    else
                    {
                        arr1[i] = "marco";

                    }
                }

                else if (arr[i] % 7 == 0)
                {
                    arr1[i] = "polo";

                }

            }
            return arr1;

        }
        static void Main(string[] args)
        {
            int[] arr = new int[100];
            string[] arr1 = new string[100];
            int n, i;

            Console.Write("Enter Size of array");
            n = Convert.ToInt32(Console.ReadLine());
            Console.Write("elements of an array:\n");
            Console.Write("-----------------------------------------\n");

            Console.Write("Input" + n + "elements in the array :\n");
            for (i = 0; i < n; i++)
            {
                Console.Write("element - {0} : ", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Program p = new Program();

            arr1 = p.display(arr, n, ref arr1);
            Console.Write("\nOutput elements are: ");

            for (i = 0; i < n; i++)
            {
                Console.Write("{0}", arr1[i]);
                if (i != n - 1)
                {
                    Console.Write(", ");
                }
            }
            Console.ReadLine();


        }
    }
}
