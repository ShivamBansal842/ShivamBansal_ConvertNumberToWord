﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MacropoloGame;

namespace MacropoloGameTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void MacroPoloGameTestMethod()
        {
            Program p = new Program();
            int n = 30;
            string[] expectedResult = { "1", "2", "3", "marco", "5", "6", "polo", "marco", "9", "10", "11", "marco", "13", "polo", "15", "marco", "17", "18", "19", "marco", "polo", "22", "23", "marco", "25", "26", "27", "marcopolo", "29", "30" };
            int[] actualintArray = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30 };
            string[] actualStringArray = new string[30];
            for (int i = 0; i < actualStringArray.Length; i++)
            {
                actualStringArray[i] = "0";
            }
            string[] actualResult = p.display(actualintArray, n, ref actualStringArray);
            CollectionAssert.AreEqual(expectedResult, actualResult);
        }

    }

}
